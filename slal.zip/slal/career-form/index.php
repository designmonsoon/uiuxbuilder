<?php
//index.php

$message = '';

function clean_text($string)
{
	$string = trim($string);
	$string = stripslashes($string);
	$string = htmlspecialchars($string);
	return $string;
}

if(isset($_POST["submit"]))
{
	$path = 'upload/' . $_FILES["resume"]["name"];
	move_uploaded_file($_FILES["resume"]["tmp_name"], $path);
	$message = '
		<h3 align="center">Applicant Details</h3>
		<table border="1" width="100%" cellpadding="5" cellspacing="5">
			<tr>
				<td width="30%">Name</td>
				<td width="70%">'.$_POST["name"].'</td>
			</tr>
			<tr>
				<td width="30%">Address</td>
				<td width="70%">'.$_POST["address"].'</td>
			</tr>
			<tr>
				<td width="30%">Email Address</td>
				<td width="70%">'.$_POST["email"].'</td>
			</tr>
			<tr>
				<td width="30%">Job Status</td>
				<td width="70%">'.$_POST["jobs"].'</td>
			</tr>
			<tr>
				<td width="30%">Desired Field</td>
				<td width="70%">'.$_POST["fields"].'</td>
			</tr>
			<tr>
				<td width="30%">Experience Year</td>
				<td width="70%">'.$_POST["experience"].'</td>
			</tr>
			<tr>
				<td width="30%">Phone Number</td>
				<td width="70%">'.$_POST["mobile"].'</td>
			</tr>
			<tr>
				<td width="30%">Additional Information</td>
				<td width="70%">'.$_POST["additional_information"].'</td>
			</tr>
		</table>
	';
	
	require 'class/class.phpmailer.php';
	$mail = new PHPMailer;
	$mail->From = $_POST["email"];					//Sets the From email address for the message
	$mail->FromName = $_POST["name"];				//Sets the From name of the message
	$mail->AddAddress('info@stylelivingbd.com', 'Style Living');		//Adds a "To" address
	$mail->WordWrap = 50;							//Sets word wrapping on the body of the message to a given number of characters
	$mail->IsHTML(true);							//Sets message type to HTML
	$mail->AddAttachment($path);					//Adds an attachment from a path on the filesystem
	$mail->Subject = 'Application for Job holder Entry';				//Sets the Subject of the message
	$mail->Body = $message;							//Plain text message body
	if($mail->Send())								//Send an Email. Return true on success or false on error
	{
		$message = '<div class="alert alert-success"><h1>Thank you..! profile is successfully submitted to desired destination.</h1></div>';
		unlink($path);
	}
	else
	{
		$message = '<div class="alert alert-danger">There is an Error</div>';
	}
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>SLAL | Career Subscription Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<link rel="apple-touch-icon" sizes="57x57" href="../fav/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../fav/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../fav/android-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../fav/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../fav/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../fav/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../fav/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../fav/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../fav/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="../fav/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../fav/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../fav/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../fav/favicon-16x16.png">
<link rel="manifest" href="../fav/manifest.json">
<meta name="msapplication-TileImage" content="../fav/ms-icon-144x144.png">
<meta name="author" content="Musa Touhid (https://designmonsoon.com/)">
<link rel="shortcut icon" href="../fav/favicon.ico" type="image/x-icon">
<link rel="icon" href="../fav/favicon.ico" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="../css/animate.css">
<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../css/icon-font.min.css">
<link rel="stylesheet" type="text/css" href="../css/ionicons.min.css">
<link rel="stylesheet" type="text/css" href="../css/slick.css">
<link rel="stylesheet" type="text/css" href="../css/slick-theme.css">
<link rel="stylesheet" type="text/css" href="../css/light-color.css">
<link rel="stylesheet" type="text/css" href="../css/style.css">
<link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../css/team.css">
<link rel="stylesheet" type="text/css" href="../css/responsive.css">
<link rel="stylesheet" type="text/css" href="../css/nxtprev.css">
<link rel="stylesheet" type="text/css" href="../css/txtbtn.css">
<link rel="stylesheet" type="text/css" href="../css/footer.css">
<link rel="stylesheet" type="text/css" href="../css/video-bg.css">
	<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
<style>
.file {
  visibility: hidden;
  position: absolute;
}
.btn:not(:disabled):not(.disabled) {
    cursor: pointer;
}
.btn.btn-primary {
  background-color:#bbb9b9;
  border-color:#bbb9b9;
  outline: none;
  color: #fff;
}
	button{
	cursor:default;
	}
	
	.block h2
	{font-weight:300;
	color:#97946b;
	font-size: 2.1em;
	text-align: left;
	padding-bottom: 2em;
	}
.block h2:before {
 content:'';
 position:absolute;
 top:40px;
 width:5%;
 height:6px;
 background-color:#97946b;
	}
@media(max-width:767px) {
.block h2:before {
 width:0%;
}
}

	</style>
</head>
	<body>
<div class="page-loading">
<div class="thecube">
<div class="cube c1"></div>
<div class="cube c2"></div>
<div class="cube c4"></div>
<div class="cube c3"></div>
</div>
</div>
<div class="wrapper ms-overlay no-fixing">
<header class="stick v2">
<div class="hd_bar">
<div class="container">
<div class="header-bar qut-style">
<div class="logo">
<a href="http://stylelivingbd.com/" title=""><img src="../images/logo.png" alt=""></a>
</div>
<nav>
<ul>
<li><a href="../" title="">Home</a></li>
<li><a href="javascript:void(0)" title="">Profile</a>
<ul>
<li><a href="../asr-about/" title="">At a glance</a></li>
<li><a href="../profile-features/" title="">Our Pholosophy</a></li>
<li><a href="../profile-vision/" title="">Vision &amp; Mission</a></li>
<li><a href="../slal-expertise/" title="">Our Expertise</a></li>
<li><a href="../organization-capacity/" title="">Organization capacity</a></li>
<li><a href="../quality-assurance/" title="">Quality Assurance</a></li>
</ul>
</li>
<li><a href="javascript:void(0)" title="">Features</a>
<ul>
<li><a href="../architectural-design/" title="">Architectural Design</a></li>
<li><a href="../technical-features/" title="">Structural Design</a></li>
<li><a href="../electrical-drawing/" title="">MEP Services</a></li>
</ul>
</li>
<li><a href="javascript:void(0)" title="">Projects</a>
<ul>
<li><a href="../gallery-slot/" title="">Top Projects</a></li>
<li><a href="javascript:void(0)" title="">Projects Gallery</a>
<ul>
<li><a href="../main-gallery/" title="">At a glance</a></li>
<li><a href="../single/" title="">Single family</a></li>
<li><a href="../multi/" title="">Multi-family</a></li>
<li><a href="../commercial/" title="">Commercial building</a></li>
<li><a href="../office/" title="">Office building</a></li>
</ul>
</li>
<li><a href="../architectural-trailers/" title="">Media Playlist</a></li>
</ul>
</li>
<li><a href="../clients-data/" title="">Clients</a></li>
<li><a href="../24x7round-the-clock/" title="">Contact</a></li>
<li class="active"><a href="../jobs-n-career" title="">Career</a></li>
</ul>
</nav>
<div class="mobile-menu-btn">
<a href="#" title="" class="open-menu"><i class="fa fa-bars"></i></a>
</div>
</div>
</div>
</div>
</header>
<div class="responsive-mobile-menu">
<a href="#" title="" class="close-menu"><i class="ion-close"></i></a>
<ul>
<li><a href="../" title="">Home</a></li>
<li><a href="../asr-about/" title="">SLAL Profile</a>
<ul>
<li><a href="../asr-about/" title="">At a glance</a></li>
<li><a href="../profile-features/" title="">Our Pholosophy</a></li>
<li><a href="../profile-vision/" title="">Vision &amp; Mission</a></li>
<li><a href="../slal-expertise/" title="">Our Expertise</a></li>
<li><a href="../organization-capacity/" title="">Organization capacity</a></li>
<li><a href="../quality-assurance/" title="">Quality Assurance</a></li>
</ul>
</li>
<li><a href="javascript:void(0)" title="">Features</a>
<ul>
<li><a href="../architectural-design/" title="">Architectural Design</a></li>
<li><a href="../technical-features/" title="">Structural Design</a></li>
<li><a href="../electrical-drawing/" title="">MEP Services</a></li>
</ul>
</li>
<li><a href="javascript:void(0)" title="">Projects</a>
<ul>
<li><a href="../gallery-slot/" title="">Top Projects</a></li>
<li><a href="javascript:void(0)" title="">Projects Gallery</a>
<ul>
<li><a href="../main-gallery/" title="">At a glance</a></li>
<li><a href="../single/" title="">Single family</a></li>
<li><a href="../multi/" title="">Multi-family</a></li>
<li><a href="../commercial/" title="">Commercial building</a></li>
<li><a href="../office/" title="">Office building</a></li>
</ul>
</li>
<li><a href="../architectural-trailers/" title="">Media Playlist</a></li>
</ul>
</li>
<li><a href="../clients-data/" title="">Client list</a></li>
<li><a href="../24x7round-the-clock/" title="">Contact</a></li>
<li class="active"><a href="../jobs-n-career" title="">Career with us</a></li>
</ul>
</div>
<main class="main main-full main-video">
<video class="home-video" autoplay loop muted poster="../images/home-image-4.jpg">
<source src="../images/handshake-job.mp4" type="video/mp4">
<!--<source src="../images/MapleLeaves-home.webm" type="video/webm">-->
</video> 
<div class="container">
<div class="opener">
<div class="row">
<div class="col-md-8 text-left-md">
<h1><strong>We look forward to  </strong>staying connected with you</h1>
<div class="lead-hr"></div>
<p class="lead">Our Talent Network will enhance your job search <br>and application process. Whether you choose to apply or just leave your information</p>
<a href="../jobs-n-career/" class="btn btn-outline-primary">Know More</a>
</div>
</div>
</div>
</div>
</main>	
<section style="background: url(../images/ash-white-poligonal.jpg) fixed no-repeat 50% 0;background-size: cover;">
<div class="container">
<div class="pager-details full text-center">
<h2 class="heading-title">Join  our talent network</h2>

</div>
</div>
</section>
<section style="background: url(../images/ash-white-poligonal.jpg) fixed no-repeat 50% 0;background-size: cover;">	
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<?php print_r($message); ?>
					<form method="post" enctype="multipart/form-data">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<input type="text" name="name" placeholder="Enter Name" class="form-control" required />
								</div>
								<div class="form-group">
									<textarea name="address" placeholder="Enter Address" class="form-control" required></textarea>
								</div>
								<div class="form-group">
									<input type="email" name="email" class="form-control" placeholder="Enter Email Address" required />
								</div>
								<div class="form-group">
									<select name="jobs" class="form-control" required>
										<option value="">Your Current Job status</option>
										<option value="Part time">Part-timer</option>
										<option value="Employed">Employed</option>
										<option value="Self-employed">Self-employed</option>
										<option value="Entrepreneur">Entrepreneur</option>
									</select>
								</div>
								<div class="form-group">
									<select name="fields" class="form-control" required>
										<option value="">Select your desired field</option>
										<option value="Civil Engineer">Civil Engineer</option>
										<option value="Interior designer">Interior designer</option>
										<option value="Administrative panel">Administrative panel</option>
										<option value="Management team">Management team</option>
									</select>
								</div>
								<!--<div class="form-group">
									<label><i class="fa fa-paperclip"></i> | Select your desired fields</label>
									<select name="programming_languages[]" class="form-control" multiple required style="height:160px">
										<option value="Structural Drawing">Structural drawing</option>
										<option value="Architectural design">Architectural design</option>
										<option value="Electrical Drwaing">Electrical drwaing</option>
										<option value="Urban drawing">Urban drawing and design</option>
										<option value="Civil Engineering">Civil Engineering</option>
										<option value="Sketch design">Sketch design</option>
										<option value="Management">Management trainee</option>
										<option value="Admin">Administrative panel</option>
										<option value="Interiors">Interior and exterior design</option>
									</select>
								</div>-->
								
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<select name="experience" class="form-control" required>
										<option value="">Select your experience</option>
										<option value="2-3 years">2-3 years</option>
										<option value="4-5 years">4-5 years</option>
										<option value="6-8 years">6-8 years</option>
										<option value="9 or more yrs">9 or more years</option>
									</select>
								</div>
								<div class="form-group">
									<input type="text" name="mobile" placeholder="Mention your mobile" class="form-control" pattern="\d*" required />
								</div>
								<div class="form-group">
    							<input type="file" name="resume" class="file" accept=".doc,.docx, .pdf" required>
    								<div class="input-group">
      									<input type="text" class="form-control" disabled placeholder="Upload File: doc/docx/pdf" aria-label="Upload File" aria-describedby="basic-addon1">
      								<div class="input-group-append">
        						<button class="browse input-group-text btn btn-primary" id="basic-addon2"> Browse</button>
      						</div>
    					</div>
  					</div>
								
								<div class="form-group">
									<textarea name="additional_information" placeholder="Enter additional information here" class="form-control" required rows="4"></textarea>
								</div>
							</div>
						</div>
						<div style="padding: 2.5em 0;" class="form-group" align="center">
							<input type="submit" name="submit" value="Submit your profile" class="btn btn-info" />
						</div>
					</form>
				</div>
			</div>
		</div>
</section>
<section class="footer_area">
			<div class="container">
				<div class="row">				
					<div class="col-md-3 col-sm-6">
						<div class="single_ftr">
							<h4 class="sf_title">Contacts</h4>
							<ul>
								<li>Style Living Architects Ltd.</li>
								<li>AK Trade Center (8th Floor) <br> 36/7 CDA Avenue, Muradpur, Chattogram.</li>
								<li>Tel +88 031 2550818 | +88 01713 441449</li>
								<li>info@stylelivingbd.com</li>
							</ul>
						</div>
					</div> <!--  End Col -->
					
					<div class="col-md-3 col-sm-6">
						<div class="single_ftr">
							<h4 class="sf_title">Information</h4>
							<ul>
								<li><a href="../asr-about/">About Us</a></li>
								<li><a href="../profile-vision/">Our vision</a></li>
								<li><a href="../slal-expertise/">Our Expertise</a></li>
								<li><a href="../organization-capacity/">Organisation capacity</a></li>
								<li><a href="../jobs-n-career/">Career with us</a></li>
							</ul>
						</div>
					</div> <!--  End Col -->
					
					<div class="col-md-3 col-sm-6">
						<div class="single_ftr">
							<h4 class="sf_title">Services</h4>
							<ul>
								<li><a href="../architectural-design/">Architectural</a></li>
								<li><a href="../technical-features/">Structural</a></li>
								<li><a href="../electrical-drawing/">Electrical</a></li>
								<li><a href="../clients-data/">Clients scenario</a></li>
								<li><a href="../architectural-trailers/">Media Playlist</a></li>
							</ul>
						</div>
					</div> <!--  End Col -->	
					
					<div class="col-md-3 col-sm-6">
						<div class="single_ftr">
							<h4 class="sf_title">Summary</h4>
							<div class="newsletter_form">
								<p>SLAL portfolio is rich by world class projects from commercial, residential, retail and mixed projects to use hospitality, leisure, healthcare, education and urban planning.</p>
								
							</div>
						</div>
					</div> <!--  End Col -->
					
				</div>
			</div>
	
		
			<div class="ftr_btm_area">
				<div class="container">
					<div class="row">
						<div class="col-sm-4">
							<div class="ftr_social_icon">
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-google"></i></a></li>
									<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-rss"></i></a></li>
								</ul>
							</div>
						</div>
						<div class="col-sm-4">
							<p class="copyright_text text-center">©2020 | Style Living Architects Ltd.</p>
						</div>
						
						<div class="col-sm-4">
							<div class="payment_mthd_icon text-right">
								<ul>
									<li><i class="fa fa-cc-visa"></i></li>
									<li><i class="fa fa-cc-discover"></i></li>
									<li><i class="fa fa-cc-mastercard"></i></li>
									<li><i class="fa fa-cc-amex"></i></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
</div>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/popper.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="../js/html5lightbox.js"></script>
<script type="text/javascript" src="../js/script.js"></script>
<script type="text/javascript" src="../js/file-input.js"></script>
<script src="../js/jquery.themepunch.tools.min.js"></script>
<script src="../js/jquery.themepunch.revolution.min.js"></script>
<script src="../js/revolution.extension.slideanims.min.js"></script>
<script src="../js/revolution.extension.layeranimation.min.js"></script>
<script src="../js/revolution.extension.navigation.min.js"></script>
<script src="../js/theme.js"></script>
	</body>
</html>





